create extension if not exists pgcrypto;

create table if not exists public.donations (
  id uuid primary key,
  txid text not null unique,
  amount numeric(12,2) not null check (amount >= 2.50 and amount <= 10000),
  status text not null default 'pending' check (status in ('pending','paid','expired','cancelled')),
  pix_copy_paste text,
  inter_location text,
  created_at timestamptz not null default now(),
  paid_at timestamptz
);

-- Browser clients must not be able to read or write donations directly.
alter table public.donations enable row level security;

-- Do not create anon policies for this table. Server uses the service role key
-- stored only in Vercel environment variables.
