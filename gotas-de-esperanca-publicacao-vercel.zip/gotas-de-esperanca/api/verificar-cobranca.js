const { createClient } = require("@supabase/supabase-js");
const { interRequest } = require("../lib/inter");

const supabase = () => createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY,
  { auth: { persistSession: false } }
);

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "GET") return res.status(405).json({ error: "Método não permitido." });
  try {
    const id = String(req.query.id || "");
    if (!/^[0-9a-f-]{36}$/i.test(id)) return res.status(400).json({ error: "Identificador inválido." });
    const db = supabase();
    const { data: donation, error } = await db.from("donations")
      .select("id,txid,amount,status")
      .eq("id", id).maybeSingle();
    if (error || !donation) return res.status(404).json({ error: "Cobrança não encontrada." });

    if (donation.status !== "paid") {
      const charge = await interRequest("GET", `/pix/v2/cob/${encodeURIComponent(donation.txid)}`);
      const paid = charge.status === "CONCLUIDA";
      if (paid) {
        const expected = Number(donation.amount).toFixed(2);
        const actual = Number(charge.valor?.original || 0).toFixed(2);
        if (expected !== actual) {
          console.error("Valor confirmado difere do registro interno", donation.txid);
          return res.status(409).json({ error: "O valor precisa de verificação manual antes da confirmação." });
        }
        const { error: updateError } = await db.from("donations")
          .update({ status: "paid", paid_at: new Date().toISOString() })
          .eq("id", id).eq("status", "pending");
        if (updateError) throw new Error("Falha ao atualizar status.");
      }
      return res.status(200).json({ status: paid ? "paid" : "pending" });
    }
    return res.status(200).json({ status: "paid" });
  } catch (error) {
    console.error("Erro ao consultar cobrança:", error.response?.data || error.message);
    return res.status(503).json({ error: "Não foi possível verificar o pagamento agora." });
  }
};
