const crypto = require("crypto");
const { createClient } = require("@supabase/supabase-js");
const { interRequest } = require("../lib/inter");

const supabase = () => createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY,
  { auth: { persistSession: false } }
);

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") return res.status(405).json({ error: "Método não permitido." });

  // Exact origin check. This is not a substitute for rate limiting/WAF.
  const allowedOrigin = process.env.PUBLIC_SITE_ORIGIN;
  const requestOrigin = req.headers.origin;
  if (allowedOrigin) {
    try {
      const expected = new URL(allowedOrigin).origin;
      if (!requestOrigin || new URL(requestOrigin).origin !== expected) {
        return res.status(403).json({ error: "Origem não permitida." });
      }
    } catch {
      return res.status(503).json({ error: "A origem pública do site não está configurada corretamente." });
    }
  }
  if (!req.headers["content-type"]?.toLowerCase().includes("application/json")) {
    return res.status(415).json({ error: "Envie a solicitação em formato JSON." });
  }

  try {
    const amount = Number(req.body && req.body.amount);
    if (!Number.isFinite(amount) || amount < 2.5 || amount > 10000) {
      return res.status(400).json({ error: "Valor inválido. Use entre R$ 2,50 e R$ 10.000,00." });
    }
    if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
      return res.status(503).json({ error: "Banco de dados ainda não configurado." });
    }

    const donationId = crypto.randomUUID();
    const txid = "GDE" + crypto.randomBytes(16).toString("hex"); // 35 alphanumeric chars
    const value = amount.toFixed(2);
    const db = supabase();

    const { error: insertError } = await db.from("donations").insert({
      id: donationId,
      txid,
      amount: value,
      status: "pending",
    });
    if (insertError) throw new Error("Não foi possível registrar a cobrança.");

    const charge = await interRequest("PUT", `/pix/v2/cob/${txid}`, {
      calendario: { expiracao: 3600 },
      valor: { original: value },
      chave: process.env.INTER_PIX_KEY,
      solicitacaoPagador: "Doação Gotas de Esperança",
      infoAdicionais: [{ nome: "Campanha", valor: "Gotas de Esperança" }],
    });

    const pixCopiaECola = charge.pixCopiaECola;
    if (!pixCopiaECola) throw new Error("O Inter não retornou o código Pix Copia e Cola.");

    const { error: updateError } = await db.from("donations").update({
      pix_copy_paste: pixCopiaECola,
      inter_location: charge.loc && charge.loc.id ? String(charge.loc.id) : null,
    }).eq("id", donationId);
    if (updateError) throw new Error("Cobrança criada, mas não foi possível salvar os dados.");

    return res.status(201).json({ donationId, amount: Number(value), pixCopiaECola });
  } catch (error) {
    console.error("Erro ao criar cobrança Pix:", error.response?.data || error.message);
    return res.status(503).json({ error: "Não foi possível gerar a cobrança. A integração precisa ser configurada ou verificada." });
  }
};
