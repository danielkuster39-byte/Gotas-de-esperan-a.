const { createClient } = require("@supabase/supabase-js");
const { interRequest } = require("../lib/inter");

const supabase = () => createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY,
  { auth: { persistSession: false } }
);

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") return res.status(405).json({ error: "Método não permitido." });

  // Do not mark a donation as paid from the webhook payload alone.
  // For each txid, re-check the official Inter API over mTLS before updating the DB.
  try {
    const events = Array.isArray(req.body?.pix) ? req.body.pix : [];
    const db = supabase();
    for (const event of events) {
      const txid = String(event.txid || "");
      if (!/^[A-Za-z0-9]{26,35}$/.test(txid)) continue;

      const { data: donation } = await db.from("donations")
        .select("id,status,amount,txid").eq("txid", txid).maybeSingle();
      if (!donation || donation.status === "paid") continue;

      const charge = await interRequest("GET", `/pix/v2/cob/${encodeURIComponent(txid)}`);
      if (charge.status !== "CONCLUIDA") continue;

      const expected = Number(donation.amount).toFixed(2);
      const actual = Number(charge.valor?.original || 0).toFixed(2);
      if (expected !== actual) {
        console.error("Valor da cobrança não corresponde ao valor armazenado", txid);
        continue;
      }

      await db.from("donations").update({
        status: "paid",
        paid_at: new Date().toISOString(),
      }).eq("id", donation.id).eq("status", "pending");
    }
    return res.status(200).json({ received: true });
  } catch (error) {
    console.error("Erro no webhook Pix:", error.response?.data || error.message);
    return res.status(500).json({ error: "Falha ao processar notificação." });
  }
};
