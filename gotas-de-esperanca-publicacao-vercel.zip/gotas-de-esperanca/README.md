# Gotas de Esperança — site e integração Pix (projeto para configuração)

Site responsivo da campanha Gotas de Esperança, com funções serverless para solicitar cobrança Pix ao Banco Inter, consultar o estado da cobrança e processar notificações, usando Supabase como registro operacional.

> **Importante:** este pacote não está certificado nem testado ponta a ponta com a conta Inter do organizador. Não aceite nem divulgue doações reais até validar a titularidade da chave Pix, os dados da instituição e o fluxo de pagamento em ambiente aprovado pelo banco. O código só marca uma contribuição como paga após consultar a API do Inter; ainda assim, a integração deve ser homologada com a documentação e as credenciais específicas da conta.

## Arquivos

- `public/index.html` — página da campanha e interface de doação.
- `api/criar-cobranca.js` — cria a cobrança e salva o registro no Supabase.
- `api/verificar-cobranca.js` — consulta a cobrança no Inter antes de responder o status.
- `api/webhook-pix.js` — processa notificações e confirma a cobrança consultando o Inter.
- `lib/inter.js` — OAuth e conexão mTLS com certificado no servidor.
- `supabase-schema.sql` — estrutura mínima de dados.
- `.env.example` — nomes das variáveis; sem segredos reais.

## 1. Supabase

1. Crie um projeto no Supabase.
2. No SQL Editor, execute `supabase-schema.sql`.
3. Em Project Settings → API, obtenha a URL do projeto e a chave `service_role`.
4. Guarde a chave `service_role` exclusivamente nas variáveis de ambiente da Vercel. Nunca a coloque no HTML, em repositório público ou em mensagens.

## 2. GitHub e Vercel

1. Crie um repositório **privado** no GitHub.
2. Envie o conteúdo desta pasta para a raiz do repositório.
3. Importe o repositório na Vercel. A pasta pública do site é `public`; as funções ficam em `api`.
4. Adicione as variáveis de ambiente da seção abaixo em Vercel → Project → Settings → Environment Variables.
5. Faça novo deployment após adicionar ou alterar variáveis.

## 3. Variáveis de ambiente

Use `.env.example` como lista. Configure valores reais somente nos painéis oficiais:

- `INTER_CLIENT_ID`, `INTER_CLIENT_SECRET`, `INTER_PIX_KEY`
- `INTER_SCOPE`, `INTER_API_BASE_URL`, `INTER_OAUTH_URL`
- Certificado: `INTER_CERT_PFX_BASE64` e opcionalmente `INTER_CERT_PASSWORD`, **ou** `INTER_CERT_PEM_BASE64` + `INTER_KEY_PEM_BASE64` e opcionalmente `INTER_KEY_PASSWORD`
- `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`
- `PUBLIC_SITE_ORIGIN` com a origem exata publicada, por exemplo `https://seu-projeto.vercel.app` (sem caminho final)

Os nomes de escopos, URLs, endpoints, formato de certificado e formato de resposta devem ser confirmados na documentação atual do Inter e na configuração da sua integração. Não presuma que o exemplo é automaticamente compatível com todas as contas.

## 4. Banco Inter

Antes de ativar pagamentos:

1. Confirme que a integração está habilitada para Pix Cobrança e que o certificado corresponde a ela.
2. Confirme os escopos autorizados para criação e consulta de cobranças.
3. Confira o formato da requisição `PUT /pix/v2/cob/{txid}`, o retorno do `pixCopiaECola` e os estados de cobrança esperados.
4. Confirme que `INTER_PIX_KEY` pertence à entidade que deve receber as doações e que o nome exibido no aplicativo bancário é o esperado.
5. Configure o webhook conforme o procedimento oficial do Inter, apontando para `https://SEU-DOMINIO/api/webhook-pix`.
6. Faça testes controlados aprovados pelo banco e confirme valor, titularidade, consulta de status, expiração e duplicidade antes de anunciar a campanha.

Documentação oficial: https://developers.inter.co/docs/introducao/nossas-apis

## 5. Segurança e limitações que ainda exigem trabalho antes de produção

- Configure rate limiting e proteção contra bots/WAF para evitar criação abusiva de cobranças. Não confie em limitação em memória em funções serverless.
- Confirme na documentação do Inter a autenticação/assinatura esperada para webhook; o endpoint reconsulta o Inter, mas o procedimento de registro e a validação da notificação ainda precisam ser verificados.
- Teste e trate falhas parciais entre criação no banco e criação da cobrança no Inter; pode ser necessário reconciliação operacional.
- Confirme o valor pago e o status com a API oficial; trate pagamentos duplicados, valores divergentes, expiração e eventos repetidos.
- Não publique total arrecadado, barra de progresso ou alegações de impacto sem dados comprovados.
- Publique país/comunidade beneficiada, parceiro local, orçamento, custos, política de privacidade e prestação de contas verificáveis antes de captar recursos.
- Não inclua certificados, tokens, chaves, arquivos `.env` ou dados de doadores no GitHub.

## Status honesto

O pacote contém a página e o backend inicial. A sintaxe JavaScript pode ser verificada localmente, mas isso não comprova conectividade com o Inter, disponibilidade do Sandbox, homologação, configuração do webhook nem processamento real. **Não considerar pronto para produção até concluir as validações acima.**
